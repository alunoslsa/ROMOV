/**
  ******************************************************************************
  * @file    main.c
  * @author  3S0 FreeRTOS nnd@isep.ipp.pt
  * @version V1.1
  * @date    28/11/2018
  * @brief   SISTR/SOTER FreeRTOS Example project
  ******************************************************************************
*/


/*
 *
 * LED blink
 *
 */

/* Standard includes. */
#include <string.h>
#include <stdio.h>
#include <stdint.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"

/*Mutex includes*/
#include "semphr.h"
#include "queue.h"

/* The rate at which encoder ticks are handled*/
#define encoderTickSend_DELAY			( ( TickType_t ) 10 / portTICK_RATE_MS )

 /* Configure RCC clock at 72 MHz */
static void prvSetupRCC( void );

/* Configure EXTI. */
static void prvSetupEXTI( void );

 /* Configure GPIO. */
static void prvSetupGPIO( void );

/* Send encoder ticks every 100 Hz. */
static void prvSendOdom( void *pvParameters );

/* Send Lidar Sync signal. */
static void prvSendLidarSync( void *pvParameters );

/* Send message to USART 2. */
static void prvSendMessage( void *pvParameters );


/********** Useful functions **********/
/* USART2 configuration. */
static void prvSetupUSART2( void );

/* USART2 send message. */
static void prvSendMessageUSART2(char *message);

/***************************************/

/*
 * Channel A - Right Wheel - PA10
 * Channel B - Right Wheel - PA12
 * Channel A - Left Wheel - PA9
 * Channel B - Left Wheel - PA8
 * Lidar Sync - PB4
 * */

/* Task 1 handle variable. */
TaskHandle_t HandleTask1;

/* Task 2 handle variable. */
TaskHandle_t HandleTask2;

/* Task 3 handle variable. */
TaskHandle_t HandleTask3;

/* Semaphore handle variable */
SemaphoreHandle_t xSemaphoreBiEncoder, xSemaphoreBiSync;

/* Data Queue handle variable */
QueueHandle_t xQueueUSART;

int32_t Wheel_R, Wheel_L;

int main( void )
{
	/*Setup the hardware, RCC, GPIO, etc...*/
    prvSetupRCC();
    prvSetupGPIO();
    prvSetupUSART2();
    prvSetupEXTI();


    /* Create Binary Semaphore for Encoder Variables */
    xSemaphoreBiEncoder = xSemaphoreCreateBinary();

    /* Create Binary Semaphore for Encoder Variables */
    xSemaphoreBiSync = xSemaphoreCreateBinary();

    xQueueUSART = xQueueCreate( 10, sizeof( char [20] ) );
    if( xQueueUSART == 0 ) {
    	return 0;
    }

	/* Create the tasks */
 	xTaskCreate( prvSendOdom, "SendOdom", configMINIMAL_STACK_SIZE+400, NULL, 1, &HandleTask1 );

 	xTaskCreate( prvSendLidarSync, "SendLidarSync", configMINIMAL_STACK_SIZE+400, NULL, 1, &HandleTask2 );

 	xTaskCreate( prvSendMessage, "SendMessage", configMINIMAL_STACK_SIZE+400, NULL, 1, &HandleTask3 );

	/* Start the scheduler. */
	vTaskStartScheduler();

	/* Will only get here if there was not enough heap space to create the idle task. */
	return 0;
}
/*-----------------------------------------------------------*/

static void prvSendOdom( void *pvParameters )
{
	char message[20];
    TickType_t xLastExecutionTime;
    int32_t Wheel_R_cpy, Wheel_L_cpy;

    xLastExecutionTime = xTaskGetTickCount();

    for( ;; )
	{
		/* Block 10 milliseconds. */
    	vTaskDelayUntil( &xLastExecutionTime, encoderTickSend_DELAY );

		xSemaphoreTake(xSemaphoreBiEncoder, ( TickType_t) portMAX_DELAY);

		Wheel_R_cpy = Wheel_R;
		Wheel_L_cpy = Wheel_L;

		Wheel_L = 0;
		Wheel_R = 0;

		xSemaphoreGive(xSemaphoreBiEncoder);

		//Create message
		sprintf(message, "%lu %li %li\n", xTaskGetTickCount(), Wheel_L_cpy, Wheel_R_cpy);

		xQueueSendToBack( xQueueUSART, &message, ( TickType_t ) portMAX_DELAY );

	}
}
/*-----------------------------------------------------------*/


static void prvSendLidarSync( void *pvParameters )
{
	/* Stops execution of the code below on first run. */
	xSemaphoreTake(xSemaphoreBiSync, ( TickType_t) portMAX_DELAY);

	char message[20];

    for( ;; )
	{
    	/*Waits for change to the Lidar Sync GPIO (PB4)*/
    	xSemaphoreTake(xSemaphoreBiSync, ( TickType_t) portMAX_DELAY);

		//Create message
		sprintf(message, "%lu L_Sync\n", xTaskGetTickCount());

		xQueueSendToBack( xQueueUSART, &message, ( TickType_t ) portMAX_DELAY );


	}
}
/*-----------------------------------------------------------*/

static void prvSendMessage( void *pvParameters )
{
	char message[20];


    for( ;; )
	{
		/* Block until receive message. */


		xQueueReceive( xQueueUSART, &message, ( TickType_t ) portMAX_DELAY );


		prvSendMessageUSART2(message);

	}
}
/*-----------------------------------------------------------*/


static void prvSetupRCC( void )
{
    /* RCC configuration - 72 MHz */
    ErrorStatus HSEStartUpStatus;

    RCC_DeInit();
    /*Enable the HSE*/
    RCC_HSEConfig(RCC_HSE_ON);
    /* Wait until HSE is ready or time out */
    HSEStartUpStatus = RCC_WaitForHSEStartUp();
    if(HSEStartUpStatus == SUCCESS)
    {
        /* Enable The Prefetch Buffer */
        FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
        /* 72 MHZ - 2 wait states */
        FLASH_SetLatency(FLASH_Latency_2);

        /* No division HCLK = SYSCLK = 72 MHz*/
        RCC_HCLKConfig(RCC_SYSCLK_Div1);
        /* PCLK1 = HCLK/2 (36MHz) */
        RCC_PCLK1Config(RCC_HCLK_Div2);
        /* PCLK2 = HCLK (72MHz)*/
        RCC_PCLK2Config(RCC_HCLK_Div1);

        /* Use PLL with HSE = 12 MHz (12 MHz * 6 = 72 MHz) */
        RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_6);
        /* Enable the PLL */
        RCC_PLLCmd(ENABLE);
        /* Wait for PLL ready */
        while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET );

        /* Select the PLL as system clock source */
        RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
        /* Wait until PLL is used as system clock */
        while( RCC_GetSYSCLKSource() != 0x08 );
    }
    else
    {
    	/* HSE error? No further action */
        while(1);
    }
}
/*-----------------------------------------------------------*/


static void prvSetupEXTI( void )
{
    /*NVIC configuration*/
    NVIC_InitTypeDef NVIC_InitStructure;

    /* Enable the EXTI2 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the EXTI3 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the EXTI4 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    EXTI_InitTypeDef EXTI_InitStructure;

    /*Configure Channel A from right wheel to rising falling trigger*/
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource10);

    EXTI_InitStructure.EXTI_Line = EXTI_Line10;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    /*Configure Channel B from right wheel to rising falling trigger*/
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource12);
    EXTI_InitStructure.EXTI_Line = EXTI_Line12;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    /*Configure Channel A from left wheel to rising falling trigger*/
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource8);

    EXTI_InitStructure.EXTI_Line = EXTI_Line8;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    /*Configure Channel B from left wheel to rising falling trigger*/
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource9);
    EXTI_InitStructure.EXTI_Line = EXTI_Line9;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    /*Configure Lidar Sync signal to rising falling trigger*/
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource4);

    EXTI_InitStructure.EXTI_Line = EXTI_Line4;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    ///USART2
    //NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    //NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    //NVIC_Init(&NVIC_InitStructure);

    /*USART2 Update Event interrupt enable*/
    //USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
}
/*-----------------------------------------------------------*/



static void prvSetupGPIO( void )
{
    /* GPIO configuration */
    GPIO_InitTypeDef GPIO_InitStructure;

    /* Enable AFIO clock */
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA , ENABLE );

    /* Enable GPIOB clock */
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB , ENABLE );

    /* Enable AFIO clock */
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_AFIO , ENABLE );

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;

    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;

    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;

    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;

    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;

    GPIO_Init(GPIOB, &GPIO_InitStructure);

}
/*-----------------------------------------------------------*/



void prvSetupUSART2( void )
{
USART_InitTypeDef USART_InitStructure;
GPIO_InitTypeDef GPIO_InitStructure;

    /* USART2 is configured as follow:
        - BaudRate = 115200 baud
        - Word Length = 8 Bits
        - 1 Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled */

    /* Enable GPIOA clock */
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA , ENABLE );

    /* USART Periph clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);


    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;

    /* Configure the USART2 */
    USART_Init(USART2, &USART_InitStructure);
    /* Enable the USART2 */
    USART_Cmd(USART2, ENABLE);
 }

/*-----------------------------------------------------------*/


/* This is a blocking send USART function */
static void prvSendMessageUSART2(char *message)
{
uint16_t cont_aux=0;

    while(cont_aux != strlen(message))
    {
        USART_SendData(USART2, (uint8_t) message[cont_aux]);
        while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET)
        {
        }
        cont_aux++;
    }
}
/*-----------------------------------------------------------*/
